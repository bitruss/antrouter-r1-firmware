m = SimpleForm("cgminer", translate("R1 Miner Status"))
m.reset = false
m.submit = false

stats = m:section(Table, luci.controller.cgminer.summary(), "Miner Status")
stats:option(DummyValue, "elapsed", translate("Elapsed"))
stats:option(DummyValue, "ghs5s", translate("GH/S(5s)"))
stats:option(DummyValue, "ghsav", translate("GH/S(avg)"))

t0 = m:section(Table, luci.controller.cgminer.pools("r1"), translate("Pools"))
t0:option(DummyValue, "pool", translate("Pool"))                          
t0:option(DummyValue, "url", translate("URL"))                            
t0:option(DummyValue, "user", translate("User"))                          
t0:option(DummyValue, "status", translate("Status"))                      
t0:option(DummyValue, "diff", translate("Diff"))                          
t0:option(DummyValue, "getworks", translate("GetWorks"))                  
t0:option(DummyValue, "priority", translate("Priority"))                  
t0:option(DummyValue, "accepted", translate("Accepted"))                  
t0:option(DummyValue, "diff1shares", translate("Diff1#"))                 
t0:option(DummyValue, "diffaccepted", translate("DiffA#"))                
t0:option(DummyValue, "diffrejected", translate("DiffR#"))                
t0:option(DummyValue, "diffstale", translate("DiffS#"))                   
t0:option(DummyValue, "rejected", translate("Rejected"))                  
t0:option(DummyValue, "discarded", translate("Discarded"))                
t0:option(DummyValue, "stale", translate("Stale"))                        
t0:option(DummyValue, "lastsharedifficulty", translate("LSDiff"))         
t0:option(DummyValue, "lastsharetime", translate("LSTime"))  

local data = {}
local flag
flag,data = luci.controller.cgminer.blocks()

if(flag == 0 or data == {}) then
	bls = m:section(Table, data, "Found Blocks")
        bls:option(DummyValue, "Comment", "")
                
else
        bls = m:section(Table, data, "FoundBlocks")
        bls:option(DummyValue, "blockInfo", translate("Block Info"))
end

                                               
return m             
--[[                                
t1 = f:section(Table, luci.controller.cgminer.summary(), "R1 Status")
t1:option(DummyValue, "num", translate("Chip Number"))
t1:option(DummyValue, "elapsed", translate("Elapsed"))
t1:option(DummyValue, "ghs5s", translate("GH/S(5s)"))
t1:option(DummyValue, "ghsav", translate("GH/S(avg)"))

t0 = f:section(Table, luci.controller.cgminer.pools(), translate("Pools"))
t0:option(DummyValue, "pool", translate("Pool"))
t0:option(DummyValue, "url", translate("URL"))
t0:option(DummyValue, "user", translate("User"))
t0:option(DummyValue, "status", translate("Status"))
t0:option(DummyValue, "diff", translate("Diff"))
t0:option(DummyValue, "getworks", translate("GetWorks"))
t0:option(DummyValue, "priority", translate("Priority"))
t0:option(DummyValue, "accepted", translate("Accepted"))
t0:option(DummyValue, "diff1shares", translate("Diff1#"))                        
t0:option(DummyValue, "diffaccepted", translate("DiffA#"))                       
t0:option(DummyValue, "diffrejected", translate("DiffR#"))                       
t0:option(DummyValue, "diffstale", translate("DiffS#"))                          
t0:option(DummyValue, "rejected", translate("Rejected"))                         
t0:option(DummyValue, "discarded", translate("Discarded"))                       
t0:option(DummyValue, "stale", translate("Stale"))                               
t0:option(DummyValue, "lastsharedifficulty", translate("LSDiff"))                
t0:option(DummyValue, "lastsharetime", translate("LSTime"))    
--]]    
