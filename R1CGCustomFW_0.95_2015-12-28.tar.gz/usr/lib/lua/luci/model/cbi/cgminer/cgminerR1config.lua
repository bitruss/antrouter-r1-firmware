m = Map("cgminer", translate("Configuration"), translate(""))

conf = m:section(TypedSection, "cgminer", "")
conf.anonymous = true
conf.addremove = false

conf:tab("default", translate("General Settings"))

pool1url = conf:taboption("default", Value, "pool1url", translate("Pool 1"))
pool1user = conf:taboption("default", Value,"pool1user", translate("Pool1 worker"))
pool1pw = conf:taboption("default", Value,"pool1pw", translate("Pool1 password"))
conf:taboption("default", DummyValue, "", translate(""))
pool2url = conf:taboption("default", Value, "pool2url", translate("Pool 2"))
pool2user = conf:taboption("default", Value, "pool2user", translate("Pool2 worker"))
pool2pw = conf:taboption("default", Value, "pool2pw", translate("Pool2 password"))
conf:taboption("default", DummyValue, "", translate(""))
pool3url = conf:taboption("default", Value, "pool3url", translate("Pool 3"))
pool3user = conf:taboption("default", Value, "pool3user", translate("Pool3 worker"))
pool3pw = conf:taboption("default", Value, "pool3pw", translate("Pool3 password"))
conf:taboption("default", DummyValue, "", translate(""))
pool4url = conf:taboption("default", Value, "pool4url", translate("Pool 4"))                                                                   
pool4user = conf:taboption("default", Value, "pool4user", translate("Pool4 worker"))                                                           
pool4pw = conf:taboption("default", Value, "pool4pw", translate("Pool4 password"))                                                             
conf:taboption("default", DummyValue, "", translate(""))  

pb = conf:taboption("default", ListValue, "pool_balance", translate("Pool Balance(Default: Failover)"))
pb.default = "  "
pb:value("  ", translate("Failover"))
pb:value("--balance", translate("Balance"))
pb:value("--load-balance", translate("Load Balance"))

--[[pb = conf:option(ListValue, "bitmain_nobeeper", translate("Beeper ringing(Default: true)"))
pb.default = "  "
pb:value("  ", translate("true"))
pb:value("--bitmain-nobeeper", translate("false"))

pb = conf:option(ListValue, "bitmain_notempoverctrl", translate("Stop running when temprerature is over 80 degrees centigrade(Default: true)"))
pb.default = "  "
pb:value("  ", translate("true"))
pb:value("--bitmain-notempoverctrl", translate("false"))
--]]
--cf = conf:option(Value, "chip_frequency", translate("Chip Frequency(Default: 300)"))

--mc = conf:option(Value, "miner_count", translate("Miner Count(Default: 24)"))
--api_allow = conf:option(Value, "api_allow", translate("API Allow(Default: W:127.0.0.1)"))

--target=conf:option(Value, "target", translate("Target Temperature"))
--overheat=conf:option(Value, "overheat", translate("Overheat Cut Off Temperature"))

--more_options = conf:option(Value, "more_options", translate("More Options(Default: --quiet)"))


conf:tab("advanced", translate("Advanced Settings"))
pb = conf:taboption("advanced", ListValue, "freq", translate("Frequency")) 
pb.default = "7:100:0783"
pb:value("2:250:0982", translate("250M"))
pb:value("2:243.75:1306", translate("243.75M"))
pb:value("2:237.5:1286", translate("237.5M"))
pb:value("2:231.25:1206", translate("231.25M"))
pb:value("2:225:0882", translate("225M"))
pb:value("3:218.75:1106", translate("218.75M"))
pb:value("3:212.5:1086", translate("212.5M"))
pb:value("3:206.25:1006", translate("206.25M"))
pb:value("3:200:0782", translate("200M"))
pb:value("3:196.88:1f07", translate("196.88M"))
pb:value("3:193.75:0f03", translate("193.75M"))
pb:value("4:187.5:0e83", translate("187.5M"))
pb:value("4:181.25:0e03", translate("181.25M"))
pb:value("4:175:0d83", translate("175M"))
pb:value("4:168.75:1a87", translate("168.75M"))
pb:value("5:162.5:0c83", translate("162.5M"))
pb:value("5:156.25:0c03", translate("156.25M"))
pb:value("5:150:0b83", translate("150M"))
pb:value("5:143.75:1687", translate("143.75M"))
pb:value("6:137.5:0a83", translate("137.5M"))
pb:value("6:131.25:0a03", translate("131.25M"))
pb:value("7:125:0983", translate("125M"))
pb:value("7:118.75:0903", translate("118.75M"))
pb:value("7:112.5:0883", translate("112.5M"))
pb:value("7:106.25:0803", translate("106.25M"))
pb:value("7:100:0783", translate("100M (default)"))


pb = conf:taboption("advanced", Value, "voltage", translate("voltage"),"Modify voltage and Save &#38; Apply, then need to Power off and Restart")
conf:option(Value,"voltage", "voltage")

local apply = luci.http.formvalue("cbi.apply")
if apply then
   io.popen("/etc/init.d/cgminer restart")
end

return m
